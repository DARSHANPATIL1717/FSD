const express = require('express');
const path = require('path');
const { connectDB } = require('./config/db');
const bookRoutes = require('./routes/books');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/api', bookRoutes);

// Base route
app.get('/', (req, res) => {
  res.json({
    message: 'Library Management System API',
    endpoints: {
      create: {
        insertOne: 'POST /api/books',
        insertMany: 'POST /api/books/bulk'
      },
      read: {
        fetchAll: 'GET /api/books',
        priceAbove300: 'GET /api/books/price-above-300',
        byCategory: 'GET /api/books/category/:category',
        projection: 'GET /api/books/projection'
      },
      update: {
        price: 'PUT /api/books/:bookId/price',
        availability: 'PUT /api/books/:bookId/availability'
      },
      replace: {
        replaceOne: 'PUT /api/books/:bookId/replace'
      },
      delete: {
        deleteOne: 'DELETE /api/books/:bookId',
        deleteMany: 'DELETE /api/books'
      },
      queryModifications: {
        sortByPriceDesc: 'GET /api/books/sort/price-desc',
        top3: 'GET /api/books/top-3'
      }
    }
  });
});

// Start server after DB connection
async function startServer() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

