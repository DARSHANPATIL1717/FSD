const express = require('express');
const { getDB } = require('../config/db');
const router = express.Router();

const collectionName = 'books';

// Helper to get collection
function getCollection() {
  return getDB().collection(collectionName);
}

// =====================
// CREATE Operations
// =====================

// Insert a single book
router.post('/books', async (req, res) => {
  try {
    const book = req.body;
    const result = await getCollection().insertOne(book);
    res.status(201).json({
      message: 'Book inserted successfully',
      insertedId: result.insertedId
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Insert multiple books
router.post('/books/bulk', async (req, res) => {
  try {
    const books = req.body;
    const result = await getCollection().insertMany(books);
    res.status(201).json({
      message: 'Books inserted successfully',
      insertedCount: result.insertedCount,
      insertedIds: result.insertedIds
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =====================
// READ Operations
// =====================

// Fetch all books
router.get('/books', async (req, res) => {
  try {
    const books = await getCollection().find({}).toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch books with price > 300
router.get('/books/price-above-300', async (req, res) => {
  try {
    const books = await getCollection().find({ price: { $gt: 300 } }).toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch books by category
router.get('/books/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const books = await getCollection().find({ category }).toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch selected fields only (projection)
router.get('/books/projection', async (req, res) => {
  try {
    // Projection: show only title, author, price; hide _id
    const books = await getCollection()
      .find({}, { projection: { title: 1, author: 1, price: 1, _id: 0 } })
      .toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =====================
// UPDATE Operations
// =====================

// Update price of a specific book by bookId
router.put('/books/:bookId/price', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const { price } = req.body;
    const result = await getCollection().updateOne(
      { bookId },
      { $set: { price } }
    );
    res.status(200).json({
      message: 'Price updated successfully',
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Modify availability status by bookId
router.put('/books/:bookId/availability', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const { available } = req.body;
    const result = await getCollection().updateOne(
      { bookId },
      { $set: { available } }
    );
    res.status(200).json({
      message: 'Availability updated successfully',
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =====================
// REPLACE Operation
// =====================

// Replace a complete book document by bookId
router.put('/books/:bookId/replace', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const newBook = req.body;
    const result = await getCollection().replaceOne(
      { bookId },
      newBook
    );
    res.status(200).json({
      message: 'Book document replaced successfully',
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =====================
// DELETE Operations
// =====================

// Delete a single book by bookId
router.delete('/books/:bookId', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const result = await getCollection().deleteOne({ bookId });
    res.status(200).json({
      message: 'Book deleted successfully',
      deletedCount: result.deletedCount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete multiple books based on condition (e.g., category)
router.delete('/books', async (req, res) => {
  try {
    const filter = req.body;
    const result = await getCollection().deleteMany(filter);
    res.status(200).json({
      message: 'Books deleted successfully',
      deletedCount: result.deletedCount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =====================
// Query Result Modifications
// =====================

// Sort books by price (descending)
router.get('/books/sort/price-desc', async (req, res) => {
  try {
    const books = await getCollection()
      .find({})
      .sort({ price: -1 })
      .toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Limit results (top 3 books)
router.get('/books/top-3', async (req, res) => {
  try {
    const books = await getCollection()
      .find({})
      .limit(3)
      .toArray();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

