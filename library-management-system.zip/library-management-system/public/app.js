const API_URL = '/api';
let allBooks = [];
let editingBookId = null;
let deletingBookId = null;

function createParticles() {
  const container = document.getElementById('particles');
  for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 60 + 20;
    p.style.width = size + 'px';
    p.style.height = size + 'px';
    p.style.left = Math.random() * 100 + '%';
    p.style.top = Math.random() * 100 + '%';
    p.style.animationDelay = Math.random() * 20 + 's';
    p.style.animationDuration = (Math.random() * 10 + 15) + 's';
    container.appendChild(p);
  }
}

function showToast(title, message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = type === 'success' ? 'fa-check' : type === 'error' ? 'fa-times' : 'fa-info-circle';
  toast.innerHTML = `
    <div class="toast-icon"><i class="fas ${icon}"></i></div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    </div>
    <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

function showLoading() { document.getElementById('loadingOverlay').classList.add('active'); }
function hideLoading() { document.getElementById('loadingOverlay').classList.remove('active'); }

async function fetchBooks() {
  showLoading();
  try {
    const res = await fetch(`${API_URL}/books`);
    allBooks = await res.json();
    applyFilters();
    updateStats();
  } catch (err) {
    showToast('Error', 'Failed to fetch books', 'error');
  }
  hideLoading();
}

function updateStats() {
  const total = allBooks.length;
  const available = allBooks.filter(b => b.available).length;
  const unavailable = total - available;
  const avgPrice = total > 0 ? Math.round(allBooks.reduce((s, b) => s + b.price, 0) / total) : 0;
  animateValue('totalBooks', parseInt(document.getElementById('totalBooks').textContent), total, 800);
  animateValue('availableBooks', parseInt(document.getElementById('availableBooks').textContent), available, 800);
  animateValue('unavailableBooks', parseInt(document.getElementById('unavailableBooks').textContent), unavailable, 800);
  animateValue('avgPrice', parseInt(document.getElementById('avgPrice').textContent), avgPrice, 800);
}

function animateValue(id, start, end, duration) {
  const el = document.getElementById(id);
  const range = end - start;
  const step = 20;
  let current = start;
  const increment = range / (duration / step);
  const timer = setInterval(() => {
    current += increment;
    if ((increment > 0 && current >= end) || (increment < 0 && current <= end) || increment === 0) {
      current = end;
      clearInterval(timer);
    }
    el.textContent = Math.round(current);
  }, step);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function renderBooks(books) {
  const grid = document.getElementById('booksGrid');
  const empty = document.getElementById('emptyState');
  if (books.length === 0) {
    grid.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';
  grid.innerHTML = books.map(book => `
    <div class="book-card">
      <div class="book-card-header">
        <div class="book-id">${book.bookId}</div>
        <div class="book-status ${book.available ? 'available' : 'unavailable'}">
          ${book.available ? 'Available' : 'Unavailable'}
        </div>
      </div>
      <div class="book-body">
        <div class="book-title">${escapeHtml(book.title)}</div>
        <div class="book-author"><i class="fas fa-user"></i> ${escapeHtml(book.author)}</div>
        <div class="book-meta">
          <div class="book-category"><i class="fas fa-tag"></i> ${escapeHtml(book.category)}</div>
          <div class="book-price">Rs. ${book.price}</div>
        </div>
      </div>
      <div class="book-actions">
        <button class="btn-icon edit" onclick="editBook(${book.bookId})" title="Edit"><i class="fas fa-pen"></i></button>
        <button class="btn-icon toggle" onclick="toggleAvailability(${book.bookId}, ${!book.available})" title="Toggle Status">
          <i class="fas ${book.available ? 'fa-eye-slash' : 'fa-eye'}"></i>
        </button>
        <button class="btn-icon delete" onclick="deleteBook(${book.bookId})" title="Delete"><i class="fas fa-trash"></i></button>
      </div>
    </div>
  `).join('');
}

function applyFilters() {
  const category = document.getElementById('filterCategory').value;
  const availability = document.getElementById('filterAvailability').value;
  const sortBy = document.getElementById('sortBy').value;
  const priceFilter = document.getElementById('filterPrice').value;
  const limit = document.getElementById('limitResults').value;

  let filtered = [...allBooks];
  if (category) filtered = filtered.filter(b => b.category === category);
  if (availability !== '') filtered = filtered.filter(b => String(b.available) === availability);
  if (priceFilter === 'above') filtered = filtered.filter(b => b.price > 300);
  if (priceFilter === 'below') filtered = filtered.filter(b => b.price <= 300);

  if (sortBy === 'price-desc') filtered.sort((a, b) => b.price - a.price);
  else if (sortBy === 'price-asc') filtered.sort((a, b) => a.price - b.price);
  else if (sortBy === 'title') filtered.sort((a, b) => a.title.localeCompare(b.title));

  if (limit) filtered = filtered.slice(0, parseInt(limit));

  renderBooks(filtered);
}

function resetFilters() {
  document.getElementById('filterCategory').value = '';
  document.getElementById('filterAvailability').value = '';
  document.getElementById('sortBy').value = '';
  document.getElementById('filterPrice').value = '';
  document.getElementById('limitResults').value = '';
  applyFilters();
}

function openAddModal() {
  editingBookId = null;
  document.getElementById('modalTitle').innerHTML = '<i class="fas fa-plus-circle"></i> Add New Book';
  document.getElementById('bookId').value = '';
  document.getElementById('bookTitle').value = '';
  document.getElementById('bookAuthor').value = '';
  document.getElementById('bookCategory').value = 'Education';
  document.getElementById('bookPrice').value = '';
  document.getElementById('bookAvailable').checked = true;
  document.getElementById('bookId').disabled = false;
  document.getElementById('bookModal').classList.add('active');
}

function closeModal() {
  document.getElementById('bookModal').classList.remove('active');
}

function editBook(bookId) {
  const book = allBooks.find(b => b.bookId === bookId);
  if (!book) return;
  editingBookId = bookId;
  document.getElementById('modalTitle').innerHTML = '<i class="fas fa-pen"></i> Edit Book';
  document.getElementById('bookId').value = book.bookId;
  document.getElementById('bookId').disabled = true;
  document.getElementById('bookTitle').value = book.title;
  document.getElementById('bookAuthor').value = book.author;
  document.getElementById('bookCategory').value = book.category;
  document.getElementById('bookPrice').value = book.price;
  document.getElementById('bookAvailable').checked = book.available;
  document.getElementById('bookModal').classList.add('active');
}

async function saveBook() {
  const bookId = parseInt(document.getElementById('bookId').value);
  const title = document.getElementById('bookTitle').value.trim();
  const author = document.getElementById('bookAuthor').value.trim();
  const category = document.getElementById('bookCategory').value;
  const price = parseFloat(document.getElementById('bookPrice').value);
  const available = document.getElementById('bookAvailable').checked;

  if (!bookId || !title || !author || !price) {
    showToast('Validation Error', 'Please fill all required fields', 'error');
    return;
  }

  showLoading();
  try {
    if (editingBookId) {
      const res = await fetch(`${API_URL}/books/${bookId}/replace`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookId, title, author, category, price, available })
      });
      if (res.ok) {
        showToast('Success', 'Book updated successfully');
      } else {
        showToast('Error', 'Failed to update book', 'error');
      }
    } else {
      const res = await fetch(`${API_URL}/books`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookId, title, author, category, price, available })
      });
      if (res.ok) {
        showToast('Success', 'Book added successfully');
      } else {
        showToast('Error', 'Failed to add book (ID may exist)', 'error');
      }
    }
    closeModal();
    await fetchBooks();
  } catch (err) {
    showToast('Error', err.message, 'error');
  }
  hideLoading();
}

async function toggleAvailability(bookId, available) {
  showLoading();
  try {
    const res = await fetch(`${API_URL}/books/${bookId}/availability`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ available })
    });
    if (res.ok) {
      showToast('Success', `Book marked as ${available ? 'available' : 'unavailable'}`);
      await fetchBooks();
    } else {
      showToast('Error', 'Failed to update availability', 'error');
    }
  } catch (err) {
    showToast('Error', err.message, 'error');
  }
  hideLoading();
}

function deleteBook(bookId) {
  const book = allBooks.find(b => b.bookId === bookId);
  deletingBookId = bookId;
  document.getElementById('deleteBookName').textContent = book ? `"${book.title}"` : '';
  document.getElementById('deleteModal').classList.add('active');
}

function closeDeleteModal() {
  document.getElementById('deleteModal').classList.remove('active');
  deletingBookId = null;
}

async function confirmDelete() {
  if (!deletingBookId) return;
  showLoading();
  try {
    const res = await fetch(`${API_URL}/books/${deletingBookId}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Success', 'Book deleted successfully');
      await fetchBooks();
    } else {
      showToast('Error', 'Failed to delete book', 'error');
    }
  } catch (err) {
    showToast('Error', err.message, 'error');
  }
  closeDeleteModal();
  hideLoading();
}

document.addEventListener('DOMContentLoaded', () => {
  createParticles();
  fetchBooks();
});

