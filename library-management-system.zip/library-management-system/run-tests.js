const { spawn } = require('child_process');
const http = require('http');

function waitForServer(maxRetries = 30) {
  return new Promise((resolve, reject) => {
    let retries = 0;
    const interval = setInterval(() => {
      const req = http.get('http://localhost:3000/', (res) => {
        clearInterval(interval);
        resolve();
      });
      req.on('error', () => {
        retries++;
        if (retries >= maxRetries) {
          clearInterval(interval);
          reject(new Error('Server did not start in time'));
        }
      });
    }, 500);
  });
}

async function main() {
  console.log('Starting server...');
  const server = spawn('node', ['server.js'], {
    cwd: __dirname,
    stdio: 'pipe'
  });

  server.stdout.on('data', (data) => {
    console.log(`[SERVER] ${data.toString().trim()}`);
  });

  server.stderr.on('data', (data) => {
    console.error(`[SERVER ERROR] ${data.toString().trim()}`);
  });

  try {
    await waitForServer();
    console.log('Server is ready. Running tests...\n');

    const test = spawn('node', ['test.js'], {
      cwd: __dirname,
      stdio: 'inherit'
    });

    test.on('close', (code) => {
      console.log(`\nTests exited with code ${code}`);
      server.kill();
      process.exit(code);
    });
  } catch (error) {
    console.error(error.message);
    server.kill();
    process.exit(1);
  }
}

main();

