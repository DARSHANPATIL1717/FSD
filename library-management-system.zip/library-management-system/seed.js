const { connectDB, closeDB } = require('./config/db');

const books = [
  {
    bookId: 1,
    title: "Database Systems",
    author: "Korth",
    price: 450,
    category: "Education",
    available: true
  },
  {
    bookId: 2,
    title: "Clean Code",
    author: "Robert C. Martin",
    price: 550,
    category: "Technology",
    available: true
  },
  {
    bookId: 3,
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    price: 250,
    category: "Fiction",
    available: false
  },
  {
    bookId: 4,
    title: "Introduction to Algorithms",
    author: "Cormen",
    price: 800,
    category: "Education",
    available: true
  },
  {
    bookId: 5,
    title: "JavaScript: The Good Parts",
    author: "Douglas Crockford",
    price: 350,
    category: "Technology",
    available: true
  },
  {
    bookId: 6,
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    price: 200,
    category: "Fiction",
    available: true
  }
];

async function seedDatabase() {
  try {
    const db = await connectDB();
    const collection = db.collection('books');

    // Clear existing data
    await collection.deleteMany({});
    console.log('Cleared existing books collection.');

    // Insert books
    const result = await collection.insertMany(books);
    console.log(`Inserted ${result.insertedCount} books successfully.`);

    await closeDB();
    process.exit(0);
  } catch (error) {
    console.error('Seeding failed:', error.message);
    process.exit(1);
  }
}

seedDatabase();

