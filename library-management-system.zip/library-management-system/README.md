# Library Management System

A complete Library Management System built with **Node.js**, **Express**, and **MongoDB** that performs all required CRUD operations on book records.

---

## Technologies Used

- **Node.js** (Server-side language)
- **Express.js** (Web framework)
- **MongoDB** (Database - supports local or MongoDB Atlas)
- **MongoDB Node.js Driver** (Native driver for database operations)

---

## Project Structure

```
library-management-system/
├── config/
│   └── db.js              # MongoDB connection configuration
├── routes/
│   └── books.js           # All CRUD API routes
├── models/                # (Reserved for future schema validation)
├── .env                   # Environment variables
├── server.js              # Main application entry point
├── seed.js                # Script to insert sample data
├── package.json           # Project dependencies
└── README.md              # Documentation
```

---

## Database Setup

- **Database Name:** `libraryDB`
- **Collection Name:** `books`

### Book Document Structure

```json
{
  "bookId": 1,
  "title": "Database Systems",
  "author": "Korth",
  "price": 450,
  "category": "Education",
  "available": true
}
```

---

## Installation & Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure MongoDB Connection
Update the `.env` file:
```env
# For local MongoDB (default)
MONGODB_URI=mongodb://127.0.0.1:27017

# OR for MongoDB Atlas
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/?retryWrites=true&w=majority

PORT=3000
```

### 3. Seed the Database (Insert 6 sample books)
```bash
npm run seed
```

### 4. Start the Server
```bash
npm start
```

Server will run at: `http://localhost:3000`

---

## API Endpoints

### CREATE Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/books` | Insert a single book |
| POST | `/api/books/bulk` | Insert multiple books |

### READ Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/books` | Fetch all books |
| GET | `/api/books/price-above-300` | Fetch books with price > 300 |
| GET | `/api/books/category/:category` | Fetch books by category |
| GET | `/api/books/projection` | Fetch selected fields only (title, author, price) |

### UPDATE Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| PUT | `/api/books/:bookId/price` | Update price of a specific book |
| PUT | `/api/books/:bookId/availability` | Modify availability status |

### REPLACE Operation

| Method | Endpoint | Description |
|--------|----------|-------------|
| PUT | `/api/books/:bookId/replace` | Replace a complete book document |

### DELETE Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| DELETE | `/api/books/:bookId` | Delete a single book |
| DELETE | `/api/books` | Delete multiple books based on condition |

### Query Result Modifications

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/books/sort/price-desc` | Sort books by price (descending) |
| GET | `/api/books/top-3` | Limit results (top 3 books) |

---

## Testing with cURL / Postman

### 1. Seed Data
```bash
npm run seed
```

### 2. Fetch All Books
```bash
curl http://localhost:3000/api/books
```

### 3. Fetch Books with Price > 300
```bash
curl http://localhost:3000/api/books/price-above-300
```

### 4. Fetch Books by Category
```bash
curl http://localhost:3000/api/books/category/Education
```

### 5. Projection (Selected Fields)
```bash
curl http://localhost:3000/api/books/projection
```

### 6. Update Price
```bash
curl -X PUT http://localhost:3000/api/books/1/price \
  -H "Content-Type: application/json" \
  -d '{"price": 500}'
```

### 7. Update Availability
```bash
curl -X PUT http://localhost:3000/api/books/1/availability \
  -H "Content-Type: application/json" \
  -d '{"available": false}'
```

### 8. Replace Document
```bash
curl -X PUT http://localhost:3000/api/books/1/replace \
  -H "Content-Type: application/json" \
  -d '{
    "bookId": 1,
    "title": "Advanced Database Systems",
    "author": "Korth & Silberschatz",
    "price": 600,
    "category": "Education",
    "available": true
  }'
```

### 9. Delete Single Book
```bash
curl -X DELETE http://localhost:3000/api/books/1
```

### 10. Delete Multiple Books (by category)
```bash
curl -X DELETE http://localhost:3000/api/books \
  -H "Content-Type: application/json" \
  -d '{"category": "Fiction"}'
```

### 11. Sort by Price Descending
```bash
curl http://localhost:3000/api/books/sort/price-desc
```

### 12. Top 3 Books
```bash
curl http://localhost:3000/api/books/top-3
```

---

## Notes

- Ensure **MongoDB** is running locally or update `.env` with your **MongoDB Atlas** connection string.
- All book IDs (`bookId`) are numeric integers.
- The `models/` folder is reserved for future use (e.g., Mongoose schema validation if needed).

---

## License

MIT
