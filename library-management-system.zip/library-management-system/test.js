const http = require('http');

function request(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path,
      method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });

    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runTests() {
  try {
    console.log('=== TESTING LIBRARY MANAGEMENT SYSTEM ===\n');

    console.log('1. Fetch all books:');
    const allBooks = await request('/api/books');
    console.log(JSON.stringify(allBooks, null, 2));
    console.log(`Total books: ${allBooks.length}\n`);

    console.log('2. Fetch books with price > 300:');
    const expensiveBooks = await request('/api/books/price-above-300');
    console.log(JSON.stringify(expensiveBooks, null, 2));
    console.log(`Count: ${expensiveBooks.length}\n`);

    console.log('3. Fetch books by category (Education):');
    const eduBooks = await request('/api/books/category/Education');
    console.log(JSON.stringify(eduBooks, null, 2));
    console.log(`Count: ${eduBooks.length}\n`);

    console.log('4. Projection (selected fields):');
    const projection = await request('/api/books/projection');
    console.log(JSON.stringify(projection, null, 2));
    console.log();

    console.log('5. Sort books by price descending:');
    const sorted = await request('/api/books/sort/price-desc');
    console.log(JSON.stringify(sorted.map(b => ({ title: b.title, price: b.price })), null, 2));
    console.log();

    console.log('6. Top 3 books:');
    const top3 = await request('/api/books/top-3');
    console.log(JSON.stringify(top3.map(b => ({ title: b.title, price: b.price })), null, 2));
    console.log();

    console.log('7. Update price of bookId 1 to 500:');
    const updatePrice = await request('/api/books/1/price', 'PUT', { price: 500 });
    console.log(JSON.stringify(updatePrice, null, 2));
    console.log();

    console.log('8. Update availability of bookId 1 to false:');
    const updateAvail = await request('/api/books/1/availability', 'PUT', { available: false });
    console.log(JSON.stringify(updateAvail, null, 2));
    console.log();

    console.log('9. Verify update - fetch bookId 1:');
    const book1 = await request('/api/books');
    console.log(JSON.stringify(book1.find(b => b.bookId === 1), null, 2));
    console.log();

    console.log('10. Replace bookId 2:');
    const replaceBook = await request('/api/books/2/replace', 'PUT', {
      bookId: 2,
      title: "Clean Architecture",
      author: "Robert C. Martin",
      price: 600,
      category: "Technology",
      available: true
    });
    console.log(JSON.stringify(replaceBook, null, 2));
    console.log();

    console.log('11. Delete single book (bookId 6):');
    const deleteOne = await request('/api/books/6', 'DELETE');
    console.log(JSON.stringify(deleteOne, null, 2));
    console.log();

    console.log('12. Delete multiple books (category Fiction):');
    const deleteMany = await request('/api/books', 'DELETE', { category: "Fiction" });
    console.log(JSON.stringify(deleteMany, null, 2));
    console.log();

    console.log('13. Final fetch all books:');
    const finalBooks = await request('/api/books');
    console.log(JSON.stringify(finalBooks, null, 2));
    console.log(`Remaining books: ${finalBooks.length}\n`);

    console.log('=== ALL TESTS COMPLETED SUCCESSFULLY ===');
    process.exit(0);
  } catch (error) {
    console.error('Test failed:', error.message);
    process.exit(1);
  }
}

runTests();

